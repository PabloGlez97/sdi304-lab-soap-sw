package com.uniovi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sdi304LabSoapSwApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sdi304LabSoapSwApplication.class, args);
	}

}
